-- Tabla de objeto tProductos --
CREATE OR REPLACE TYPE tProductos AS OBJECT (
    id_producto varchar(5),
    nombre varchar(30),
    stock integer,
    precio float,
    disponible number(1),
    MEMBER FUNCTION verDetalle RETURN varchar
);
-- M�todo de tProductos --
CREATE OR REPLACE TYPE BODY tProductos AS
    MEMBER FUNCTION verDetalle RETURN varchar IS
    BEGIN
        IF disponible = 1 THEN
            RETURN 'El producto ' || nombre || ' tiene ' || stock || ' unidades disponibles, a ' || precio || '� la unidad.';
        ELSE
            RETURN 'El producto ' || nombre || ' se ha agotado por el momento.';
        END IF;
    END;
END;
-- Tabla productos que se relaciona con tProductos --
CREATE TABLE productos OF tProductos;
ALTER TABLE productos ADD PRIMARY KEY(id_producto);






-- Tabla de objeto tClientes --
CREATE OR REPLACE TYPE tClientes AS OBJECT (
    cif_cliente char(9),
    nombre varchar(30),
    telefono char(9),
    numero_cuenta_bancaria char(10),
    direccion varchar(50),
    MEMBER FUNCTION detalleCliente RETURN varchar
);
-- M�todo de tClientes --
CREATE OR REPLACE TYPE BODY tClientes AS
    MEMBER FUNCTION detalleCliente RETURN varchar IS
    BEGIN
        RETURN 'El cliente '||nombre||', con CIF '||cif_cliente||', tiene como direcci�n: '||direccion||'.';
    END;
END;
-- Tabla clientes que se relaciona con tClientes --
CREATE TABLE clientes OF tClientes;
-- Primary key --
ALTER TABLE clientes ADD PRIMARY KEY(cif_cliente);






-- Tabla de objeto tFacturas --
CREATE OR REPLACE TYPE tFacturas AS OBJECT (
    id_factura char(5),
    fecha DATE,
    MEMBER FUNCTION detalleFacturas RETURN varchar
);
-- M�todo de tFacturas --
CREATE OR REPLACE TYPE BODY tFacturas AS
    MEMBER FUNCTION detalleFacturas RETURN varchar IS
    BEGIN
        RETURN 'La factura numero '||id_factura||' se realiz� el '||fecha;
    END;
END;
-- Tabla clientes que se relaciona con tClientes --
CREATE TABLE facturas OF tFacturas;
-- Primary key --
ALTER TABLE facturas ADD PRIMARY KEY(id_factura);






-- Tabla de objeto tTransportistas --
CREATE OR REPLACE TYPE tTransportistas AS OBJECT (
    id_transportista char(5),
    nombre varchar(10),
    dni char(9),
    edad char(2),
    MEMBER FUNCTION detalleTransportistas RETURN varchar
);
-- M�todo de tTransportistas --
CREATE OR REPLACE TYPE BODY tTransportistas AS
    MEMBER FUNCTION detalleTransportistas RETURN varchar IS
    BEGIN
        IF id_transportista='00001' THEN
            RETURN 'El cami�n asginado al transportista '||id_transportista||', tiene como matricula: 4875-GBD';
        ELSIF id_transportista='00002' THEN
            RETURN 'El cami�n asginado al transportista '||id_transportista||', tiene como matricula: 8695-XZJ';
        END IF;
    END;
END;
-- Tabla transportistas que se relaciona con tTransportistas --
CREATE TABLE transportistas OF tTransportistas;
-- Primary key --
ALTER TABLE transportistas ADD PRIMARY KEY(id_transportista);






-- Tabla de objeto tPedidos --
CREATE OR REPLACE TYPE tPedidos AS OBJECT (
    id_pedido varchar(5),
    id_transportista_recogida char(5),
    id_transportista_entrega char(5),
    cif_cliente char(9),
    id_factura char(5)
);
-- Tabla pedidos que se relaciona con tPedidos --
CREATE TABLE pedidos OF tPedidos;
-- Primary key --
ALTER TABLE pedidos ADD PRIMARY KEY(id_pedido);
-- Claves for�neas --
ALTER TABLE pedidos ADD CONSTRAINT fk_id_transportista_recogida FOREIGN KEY (id_transportista_recogida) REFERENCES transportistas(id_transportista);
ALTER TABLE pedidos ADD CONSTRAINT fk_id_transportista_entrega FOREIGN KEY (id_transportista_entrega) REFERENCES transportistas(id_transportista);
ALTER TABLE pedidos ADD CONSTRAINT fk_cif_cliente FOREIGN KEY (cif_cliente) REFERENCES clientes(cif_cliente);
ALTER TABLE pedidos ADD CONSTRAINT fk_id_factura FOREIGN KEY (id_factura) REFERENCES facturas(id_factura);






-- Tabla de objeto pedidos_productos --
CREATE OR REPLACE TYPE tPedidos_productos AS OBJECT (
    id_pedido varchar(5),
    id_producto varchar(5)
);
-- Tabla pedidos que se relaciona con tPedidos_productos --
CREATE TABLE pedidos_productos OF tPedidos_productos;
-- Claves for�neas --
ALTER TABLE pedidos_productos ADD CONSTRAINT fk_id_producto FOREIGN KEY (id_producto) REFERENCES productos(id_producto);
ALTER TABLE pedidos_productos ADD CONSTRAINT fk_id_pedido FOREIGN KEY (id_pedido) REFERENCES pedidos(id_pedido);




-- INSERTS a las tablas --
INSERT INTO productos VALUES ('1','Bid�n antig�o',4,29.95,1);
INSERT INTO productos VALUES ('2','Casco Vikingo',0,15.85,0);
INSERT INTO productos VALUES ('3','Pistola de pirata',2,10.99,1);
INSERT INTO productos VALUES ('4','Granadas',23,11.50,1);
INSERT INTO productos VALUES ('5','Mancuerna antigua',9,7.85,1);
-- INSERT inv�lido --
INSERT INTO productos VALUES ('5',Mancuerna antigua,f,7.85,1);

INSERT INTO clientes VALUES ('458697123','Cines Paco','844523548','1245789632','Av. Juanes 9');
INSERT INTO clientes VALUES ('639862475','Teatros Juan','478963258','3269695874','Plaza de los enanos 19');
INSERT INTO clientes VALUES ('778996584','Cines y teatros Perico','726248496','0254804661','Av. Abracadabra 2');
-- INSERT inv�lido --
INSERT INTO clientes VALUES ('894152156','Empresa PedroCines',159753682,9852963741,'Av. de Nuevo San Juan Parangaricutiro / Pueblo de M�xico 56');

INSERT INTO facturas VALUES ('04001',TO_DATE('2023-05-16', 'YYYY-MM-DD'));
INSERT INTO facturas VALUES ('04002',TO_DATE('2023-05-17', 'YYYY-MM-DD'));
INSERT INTO facturas VALUES ('04003',TO_DATE('2023-05-18', 'YYYY-MM-DD'));
INSERT INTO facturas VALUES ('04004',TO_DATE('2023-05-19', 'YYYY-MM-DD'));
-- INSERT inv�lido --
INSERT INTO facturas VALUES ('04005','2023-05-19');

INSERT INTO transportistas VALUES ('00001','Francisco','78457845N',39);
INSERT INTO transportistas VALUES ('00002','Francisca','63985278H',48);
-- INSERT inv�lido --
INSERT INTO transportistas VALUES ('00002','Pepe','78963254F','48');

INSERT INTO pedidos VALUES ('1','00001','00002','458697123','04001');
INSERT INTO pedidos VALUES ('2','00002','00002','639862475','04002');
INSERT INTO pedidos VALUES ('3','00001','00001','778996584','04003');
INSERT INTO pedidos VALUES ('4','00002','00001','778996584','04004');
-- INSERT inv�lido --
INSERT INTO pedidos VALUES ('5','00004','00004','639862475','04005');

INSERT INTO pedidos_productos VALUES ('1','1');
INSERT INTO pedidos_productos VALUES ('2','4');
INSERT INTO pedidos_productos VALUES ('3','3');
INSERT INTO pedidos_productos VALUES ('4','5');
-- INSERT inv�lido --
INSERT INTO pedidos_productos VALUES ('5','10');