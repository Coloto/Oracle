-- SELECT 1 para ver cada factura asociada a cada cliente --
SELECT clientes.cif_cliente, clientes.nombre, telefono, direccion, facturas.id_factura, fecha, productos.nombre FROM clientes 
INNER JOIN pedidos ON clientes.cif_cliente=pedidos.cif_cliente 
INNER JOIN facturas ON pedidos.id_factura=facturas.id_factura
INNER JOIN pedidos_productos ON pedidos.id_pedido=pedidos_productos.id_pedido
INNER JOIN productos ON productos.id_producto=pedidos_productos.id_producto;

-- SELECT 2 para ver el cat�logo de productos --
SELECT nombre, precio, p.verDetalle() FROM productos p;

-- SELECT 3 para que los transportistan vean que pedidos tienen que entregar y recoger, y a donde tienen que llevarlo --
SELECT transportistas.id_transportista, transportistas.nombre, id_pedido, pedidos.id_transportista_entrega, pedidos.id_transportista_recogida, pedidos.cif_cliente, c.detalleCliente() FROM transportistas 
INNER JOIN pedidos ON transportistas.id_transportista=pedidos.id_transportista_entrega
INNER JOIN clientes c ON pedidos.cif_cliente=c.cif_cliente;

-- SELECT 4 muestra el detalle de una factura especifica --
SELECT f.detalleFacturas() AS detalle_factura FROM facturas f WHERE f.id_factura = '04003';

-- SELECT 5 muestra todos los productos asociados a un pedido especifico --
SELECT productos.id_producto, id_pedido, nombre, precio FROM productos 
INNER JOIN pedidos_productos ON productos.id_producto=pedidos_productos.id_producto WHERE pedidos_productos.id_pedido=2;

-- SELECT 6 para que los transportistas vean que camion manejan --
SELECT nombre, t.detalleTransportistas() FROM transportistas t;

-- SELECT 7 muestra los clientes que realizaron pedidos y la cantidad de pedidos que han realizado --
SELECT c.nombre AS nombre_cliente, COUNT(p.id_pedido) AS cantidad_pedidos FROM clientes c
INNER JOIN pedidos p ON c.cif_cliente = p.cif_cliente GROUP BY c.nombre;

-- SELECT 8 muestra los detalles de los productos que est�n disponibles en stock --
SELECT nombre, stock FROM productos WHERE disponible = 1;

-- SELECT 9 muestra los pedidos que cada transportista ha recogido --
SELECT t.nombre AS nombre_transportista, p.id_pedido FROM transportistas t
INNER JOIN pedidos p ON t.id_transportista = p.id_transportista_recogida;

-- SELECT 10 para mostrar la factura de un pedido especifico --
SELECT facturas.id_factura, id_pedido, fecha FROM facturas 
INNER JOIN pedidos ON facturas.id_factura=pedidos.id_factura WHERE id_pedido='1';

-- SELECT 11 muestra el nombre del producto y la direcci�n del cliente para cada pedido entregado --
SELECT pedidos.nombre AS nombre_producto, direccion FROM pedidos
INNER JOIN productos ON pedidos.id_producto = productos.id_producto
INNER JOIN clientes ON pedidos.cif_cliente = clientes.cif_cliente
WHERE pedidos.id_transportista_entrega IS NOT NULL;

-- SELECT 12 muestra el nombre del cliente y el n�mero de cuenta bancaria de los clientes que hayan realizado un pedido de un producto agotado --
SELECT nombre numero_cuenta_bancaria FROM pedidos
INNER JOIN clientes ON clientes.cif_cliente = pedidos.cif_cliente
INNER JOIN productos ON productos.id_producto = pedido.id_producto
WHERE disponible = 0;

-- SELECT 13 muestra el nombre del producto y el nombre del transportista de recogida para cada pedido --
SELECT productos.nombre, transportistas.nombre FROM pedidos
INNER JOIN productos ON pedidos.id_producto = productos.id_producto
INNER JOIN transportistas ON pedidos.id_transportista_recogida = transportistas.id_transportista;

-- SELECT 14 muestra el nombre del cliente y el nombre del transportista encargado de la recogida para un pedido espec�fico --
SELECT clientes.nombre AS nombre_cliente, transportistas.nombre AS nombre_transportista FROM pedidos
INNER JOIN clientes ON pedidos.cif_cliente = clientes.cif_cliente
INNER JOIN transportistas ON pedidos.id_transportista_recogida = transportistas.id_transportista
WHERE pedidos.id_pedido = '2';

-- SELECT 15 muestra los nombres de los productos y los nombres de los clientes para los pedidos entregados por un transportista espec�fico --
SELECT productos.nombre AS nombre_producto, clientes.nombre AS nombre_cliente FROM pedidos
INNER JOIN productos ON pedidos.id_producto = productos.id_producto
INNER JOIN clientes ON pedidos.cif_cliente = clientes.cif_cliente
INNER JOIN transportistas t ON pedidos.id_transportista_entrega = transportistas.id_transportista
WHERE t.id_transportista = '00002';

-- SELECT 16 muestra el n�mero de cuenta bancaria y la direcci�n de entrega de los clientes que han realizado pedidos --
SELECT numero_cuenta_bancaria, direccion FROM clientes
INNER JOIN pedidos ON clientes.cif_cliente = pedidos.cif_cliente;

-- SELECT 17 muestra el listado de los productos del pecio mas barato al m�s alto --
SELECT nombre, precio, stock FROM productos ORDER BY precio;

-- SELECT 18 muestra el nombre del cliente y el detalle de todos los productos que ha comprado --
SELECT clientes.nombre, p.verDetalle() FROM clientes
INNER JOIN pedidos ON c.cif_cliente = pedidos.cif_cliente
INNER JOIN pedidos_productos ON pedidos.id_pedido = pedidos_productos.id_pedido
INNER JOIN productos p ON pedidos_productos.id_producto = p.id_producto;

-- SELECT 19 muestra el nombre del producto y el nombre del cliente para los pedidos que han sido entregados por un transportista que tiene cierto texto --
SELECT pr.nombre, clientes.nombre FROM productos pr
INNER JOIN pedidos_productos ON pr.id_producto = pedidos_productos.id_producto
INNER JOIN pedidos ON pedidos_productos.id_pedido = pedidos.id_pedido
INNER JOIN clientes ON pedidos.cif_cliente = clientes.cif_cliente
INNER JOIN transportistas ON pedidos.id_transportista_entrega = transportistas.id_transportista
WHERE transportistas.nombre LIKE '%isca%';

-- SELECT 20 muestra el nombre del producto y el nombre del cliente para los pedidos que han sido entregados por un transportista que tiene una determinada edad --
SELECT pr.nombre, clientes.nombre FROM productos pr
INNER JOIN pedidos_productos ON pr.id_producto = pedidos_productos.id_producto
INNER JOIN pedidos ON pedidos_productos.id_pedido = pedidos.id_pedido
INNER JOIN clientes ON pedidos.cif_cliente = clientes.cif_cliente
INNER JOIN transportistas ON pedidos.id_transportista_entrega = transportistas.id_transportista
WHERE transportistas.edad = 48;

